import {TikFinity} from './tikfinity.js';
const $=id=>document.getElementById(id),live=new URLSearchParams(location.search).has('live'),letters='ABCD';
let serverConnected=false;let snapshot=null,arrived=0,lastQ='',lastRank='',alertKey='',audio,mode='real',adapterStatus='',lastStatusSent=0;
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
async function command(action,data={}){
 try{const r=await fetch('/api/command',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,data})});if(!r.ok)throw Error(r.status);return await r.json();}
 catch(e){$('sessionStatus').textContent='Servidor indisponível · tentando reconectar';}
}
function text(id,value){const el=$(id);if(el&&el.textContent!==String(value))el.textContent=value;}
function resize(){document.documentElement.style.setProperty('--frame-scale',Math.min(innerWidth/1080,innerHeight/1920));}
if(live){document.body.classList.add('broadcast');resize();addEventListener('resize',resize);}
function beep(){if(live||!$('sfx').checked)return;try{audio??=new AudioContext();audio.resume();const o=audio.createOscillator(),g=audio.createGain();g.gain.setValueAtTime(.025,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+.12);o.frequency.value=850;o.connect(g).connect(audio.destination);o.start();o.stop(audio.currentTime+.13);}catch{}}
function burst(){if(reduced)return;const host=$('fxLayer');if(host.children.length>24)return;for(let i=0;i<14;i++){const n=document.createElement('span');n.className='fx-piece';for(const [k,v] of Object.entries({x:(15+Math.random()*70)+'%',y:'82%',dx:(Math.random()*280-140)+'px',dy:(-50-Math.random()*160)+'px',rotate:'180deg',speed:'1.4s',size:'10px',color:['#65f6e9','#ffd36f','#b6a1ff'][i%3]}))n.style.setProperty('--'+k,v);host.append(n);setTimeout(()=>n.remove(),1600);}}
function render(s){
 serverConnected=true;snapshot=s;arrived=performance.now();const q=s.q;const running=s.state==='running',reveal=q?.correct!==undefined;
 text('sessionStatus','Jogo: '+({idle:'aguardando início',running:'rodada em andamento',paused:'pausado',reveal:'resposta revelada',interval:'intervalo',ready:'aguardando próxima rodada'}[s.state]||s.state));
 text('socketStatus','TikFinity: '+s.connection+(s.eventAge===null?' · sem eventos':` · último evento há ${Math.floor(s.eventAge)}s`));
 text('viewerStatus','Visor: sincronizado pelo servidor local (inclusive OBS)');
 text('rotatingMessage',s.mode.startsWith('TESTE')?'TESTE · SIMULAÇÃO':(s.connection.includes('eventos recebidos')?'COMENTE A, B, C OU D':'JOGUE GRÁTIS · A / B / C / D'));
 text('lastWinner',s.rank.length?'Líder: '+s.rank[0].name:'Entre para o Top 3');
 text('roundBadge','#'+String(s.round).padStart(3,'0'));text('category',q?.cat||'QI ARENA');text('difficulty','NÍVEL '+(q?.level||s.settings.level));
 text('headline',s.state==='idle'?'Seu próximo desafio':s.state==='interval'?'Respire. Vem mais!':reveal?'Confira a solução':s.phase==='memorize'?'Guarde a sequência':'Desafio da vez');
 text('subhead',s.state==='idle'?'Leia → comente A/B/C/D → acerte e pontue':reveal?'Confira a alternativa destacada e a explicação.':s.state==='paused'?'Uma pausa rápida. Já voltamos.':'Sua primeira resposta vale. Participação gratuita.');
 text('question',s.state==='idle'?'Pronto para jogar?':reveal?('Resposta '+letters[q.correct]+' · '+q.ans[q.correct]+'\n'+q.solution):(q?.q||'Aguarde o desafio'));
 $('question').className='questionText'+(($('question').textContent.length>30)?' smaller':$('question').textContent.length<17?' large':'');
 text('responseCount',s.count+' resposta'+(s.count===1?'':'s'));
 text('phase',({idle:'AGUARDANDO INÍCIO',paused:'PAUSADO',reveal:'RESPOSTA '+letters[q?.correct],interval:'PRÓXIMA RODADA',ready:'AGUARDANDO OPERADOR'}[s.state])||(s.phase==='memorize'?'MEMORIZE · 5s':'COMENTE A / B / C / D'));
 text('hint',q?.hint?'💡 '+q.hint:reveal?'✓ '+s.count+' participantes · próxima rodada em instantes':'⚡ Acertos: 100 a 150 pontos • mais rápido, mais pontos');
 document.querySelector('.answer-title').textContent=reveal?'RESPOSTA CORRETA EM DESTAQUE':'QUAL ALTERNATIVA ESTÁ CERTA?';
 document.querySelector('.card-label').textContent=reveal?'SOLUÇÃO DO DESAFIO':'SUA MISSÃO';
 document.querySelector('.sec').textContent=(reveal||s.state==='interval')?'até a próxima rodada':'segundos restantes';
 document.querySelector('.gift.rose small').textContent=s.settings.roseId?'+3s • teto +9s':'Efeito visual';
 document.querySelector('.gift.tiktok small').textContent=s.settings.hintId?'1 dica / rodada':'Efeito visual';
 text('microcopy',reveal?'ENTENDEU? VEM MAIS UM DESAFIO!':s.phase==='memorize'?'Memorize: as opções aparecem em 5 segundos.':'COMENTE A / B / C / D · JOGUE GRÁTIS');
 const signature=JSON.stringify([q?.id,s.phase,s.state==='idle']);
 if(signature!==lastQ){lastQ=signature;$('answers').replaceChildren();if(q&&s.state!=='idle')q.ans.forEach((a,i)=>{const box=document.createElement('div');box.className='answer';box.dataset.index=i;for(const [cls,val] of [['letter',letters[i]],['answer-text',a],['vote-number','0']]){const el=document.createElement('span');el.className=cls;el.textContent=val;box.append(el);}$('answers').append(box);});if(!reduced)$('card').animate([{opacity:.4,transform:'translateY(12px)'},{opacity:1,transform:'translateY(0)'}],{duration:350});}
 [...$('answers').children].forEach((box,i)=>{box.classList.toggle('correct',reveal&&q.correct===i);box.querySelector('.vote-number').textContent=s.votes[i];box.style.setProperty('--votes',(s.count?100*s.votes[i]/s.count:0)+'%');});
 const questionNode=$('question');questionNode.style.fontSize='';
 let fitSize=parseFloat(getComputedStyle(questionNode).fontSize);
 while((questionNode.scrollHeight>questionNode.clientHeight+1||questionNode.scrollWidth>questionNode.clientWidth+1)&&fitSize>38){fitSize-=2;questionNode.style.fontSize=fitSize+'px';}
 const rankSignature=JSON.stringify(s.rank);if(rankSignature!==lastRank){lastRank=rankSignature;[...$('leaderboard').children].forEach((el,i)=>{el.querySelector('strong').textContent=s.rank[i]?.name||['Seu nome aqui','Participe','Comente!'][i];el.querySelector('.pts').textContent=(s.rank[i]?.points||0)+' pts';if(!reduced)el.animate([{transform:'translateY(6px)',opacity:.6},{transform:'none',opacity:1}],{duration:400});});$('top10').replaceChildren();for(const r of s.rank){const li=document.createElement('li');li.textContent=r.name+' · '+r.points+' pts';$('top10').append(li);}}
 if(s.alert){const key=JSON.stringify(s.alert);if(alertKey!==key){alertKey=key;text('toast',s.alert.text);$('toast').classList.remove('visible');void $('toast').offsetWidth;$('toast').classList.add('visible');if(s.alert.kind==='gift')burst();beep();}}else{$('toast').classList.remove('visible');alertKey='';}
 text('log',s.logs.join('\n'));
 const video=$('presenter');if(s.settings.videoURL&&video.dataset.serverURL!==s.settings.videoURL){video.src=s.settings.videoURL;video.dataset.serverURL=s.settings.videoURL;}else if(!s.settings.videoURL&&video.dataset.serverURL){video.removeAttribute('src');delete video.dataset.serverURL;}video.muted=s.settings.videoMuted;const when=s.settings.videoWhen;video.classList.toggle('show',!!video.src&&((s.state==='idle'&&when!=='interval')||(['reveal','interval'].includes(s.state)&&when!=='idle')));if(video.src){if(video.classList.contains('show'))video.play().catch(()=>{});else video.pause();}
 if(!live&&document.activeElement?.closest('.panel')===null){for(const k of ['duration','interval','level','roseId','hintId','specialId','blocked'])$(k).value=s.settings[k];for(const k of ['auto','persist','moderation'])$(k).checked=s.settings[k];}
}
const stream=new EventSource('/api/events');stream.onmessage=e=>{try{render(JSON.parse(e.data));}catch(err){console.error(err);}};
stream.onerror=()=>{serverConnected=false;text('phase','RECONECTANDO AO SERVIDOR');text('sessionStatus','Servidor local desconectado · reconexão automática');};
function tick(){if(snapshot&&serverConnected){let left=snapshot.remaining;if(['running','reveal','interval'].includes(snapshot.state))left=Math.max(0,left-(performance.now()-arrived)/1000);text('timer',String(Math.ceil(left)).padStart(2,'0'));$('progress').style.width=Math.max(0,Math.min(100,100*left/snapshot.total))+'%';document.querySelector('.canvas').classList.toggle('danger',snapshot.state==='running'&&left<=5);if(snapshot.state==='running'&&left===0)text('phase','ENCERRANDO RESPOSTAS');}requestAnimationFrame(tick);}requestAnimationFrame(tick);
$('openViewer').onclick=()=>window.open('/?live=1','_blank','noopener');
for(const id of ['start','pause','next','stop','reset','resetRank'])$(id).onclick=()=>command(id);
async function saveSettings(){const data={};for(const k of ['duration','interval','level'])data[k]=Number($(k).value);for(const k of ['roseId','hintId','specialId','blocked'])data[k]=$(k).value;for(const k of ['auto','persist','moderation'])data[k]=$(k).checked;await command('settings',data);}
for(const id of ['duration','interval','level','auto','persist','moderation','blocked'])$(id).onchange=saveSettings;$('saveIds').onclick=saveSettings;
function simulate(event,data={}){return command('event',{event,simulated:true,data:{userId:$('tester').value||'Visitante',nickname:$('tester').value||'Visitante',msgId:crypto.randomUUID(),...data}});}
for(const c of letters)$('test'+c).onclick=()=>simulate('chat',{comment:c});
$('testRose').onclick=()=>simulate('gift',{giftId:snapshot?.settings.roseId||'SEM_MAPEAMENTO',giftType:0});
$('testTikTok').onclick=()=>simulate('gift',{giftId:snapshot?.settings.hintId||'SEM_MAPEAMENTO',giftType:0});
$('testGift').onclick=()=>simulate('gift',{giftId:snapshot?.settings.specialId||'cosmetic',giftType:0});
$('testFollow').onclick=()=>simulate('follow');$('testLike').onclick=()=>simulate('like',{likeCount:100});
async function uploadVideo(file){
 text('videoStatus','Carregando MP4 local…');
 try{if(file.size>250*1024*1024)throw Error('Limite de 250 MB');const r=await fetch('/api/video',{method:'POST',headers:{'Content-Type':'video/mp4'},body:file});const data=await r.json();if(!r.ok)throw Error(data.error);await command('settings',{videoURL:data.url,videoMuted:$('videoMute').checked,videoWhen:$('videoWhen').value});text('videoStatus','MP4 disponível no painel e no visor.');}catch(e){text('videoStatus','Falha: '+e.message);}
}
$('videoFile').onchange=()=>{const file=$('videoFile').files[0];if(file)uploadVideo(file);};
$('videoMute').onchange=()=>command('settings',{videoMuted:$('videoMute').checked});
$('videoWhen').onchange=()=>command('settings',{videoWhen:$('videoWhen').value});
$('removeVideo').onclick=()=>command('settings',{videoURL:''});
let adapter,leaseTimer;const owner=crypto.randomUUID();
const eventQueue=[];let draining=false;
function enqueue(p){if(eventQueue.length>=20000){text('socketStatus','Capacidade atingida: 20.000 eventos pendentes.');return;}eventQueue.push({...p,round:snapshot?.round,simulated:mode==='mock'});}
async function drain(){if(draining||!eventQueue.length)return;draining=true;const batch=eventQueue.splice(0,100);const sent=await command('events',batch);if(!sent)eventQueue.unshift(...batch.slice(0,20000-eventQueue.length));draining=false;if(sent&&eventQueue.length)queueMicrotask(drain);}
if(!live)setInterval(drain,50);
async function lease(){try{const r=await fetch('/api/lease',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({owner})});const {acquired}=await r.json();if(acquired&&!adapter){adapter=new TikFinity({url:mode==='mock'?'ws://localhost:21214/':'ws://localhost:21213/',event:enqueue,status:status=>{adapterStatus=status;const now=Date.now();if(now-lastStatusSent>2000||status!=='eventos recebidos'){lastStatusSent=now;command('status',{status,mode:mode==='mock'?'TESTE · SIMULADOR WEBSOCKET':'REAL · AGUARDANDO EVENTOS'});}}});adapter.start();}else if(!acquired&&adapter){adapter.stop();adapter=null;}}catch{}}
if(!live){lease();leaseTimer=setInterval(lease,4000);$('source').onchange=()=>{mode=$('source').value;if(adapter){adapter.stop();adapter=null;}lease();};}
